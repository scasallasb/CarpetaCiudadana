'use strict';

var utils = require('../utils/writer.js');
var Ciudadano = require('../service/CiudadanoService');

module.exports.ciudadanoIdCarpetaGET = function ciudadanoIdCarpetaGET (req, res, next, id) {
  Ciudadano.ciudadanoIdCarpetaGET(id)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.ciudadanoLista = function ciudadanoLista (req, res, next) {
  Ciudadano.ciudadanoLista()
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};
