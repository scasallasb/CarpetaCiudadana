'use strict';


/**
 * Obtener la carpeta de un ciudadano
 *
 * id String 
 * returns Carpeta
 **/
exports.ciudadanoIdCarpetaGET = function(id) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "documentos" : [ {
    "tipo" : "tipo",
    "estado" : "certificado",
    "entidadEmisoraId" : "entidadEmisoraId",
    "metadatos" : [ {
      "clave" : "clave",
      "valor" : "valor"
    }, {
      "clave" : "clave",
      "valor" : "valor"
    } ],
    "fechaEmision" : "2000-01-23",
    "id" : "id"
  }, {
    "tipo" : "tipo",
    "estado" : "certificado",
    "entidadEmisoraId" : "entidadEmisoraId",
    "metadatos" : [ {
      "clave" : "clave",
      "valor" : "valor"
    }, {
      "clave" : "clave",
      "valor" : "valor"
    } ],
    "fechaEmision" : "2000-01-23",
    "id" : "id"
  } ],
  "fechaCreacion" : "2000-01-23",
  "id" : "id",
  "ciudadanoId" : "ciudadanoId"
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Listar ciudadanos
 * Lista de ciudadanos
 *
 * returns List
 **/
exports.ciudadanoLista = function() {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = [ {
  "correoCarpeta" : "",
  "id" : "id",
  "nombre" : "nombre",
  "operadorId" : "operadorId"
}, {
  "correoCarpeta" : "",
  "id" : "id",
  "nombre" : "nombre",
  "operadorId" : "operadorId"
} ];
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}

