'use strict';


/**
 * Registrar documento
 *
 * body Documento 
 * no response value expected for this operation
 **/
exports.documentoPOST = function(body) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}

